﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Tab
{
    public enum TabStyle
    {
        Tab,
        Pill,
        PillVertical
    }
}