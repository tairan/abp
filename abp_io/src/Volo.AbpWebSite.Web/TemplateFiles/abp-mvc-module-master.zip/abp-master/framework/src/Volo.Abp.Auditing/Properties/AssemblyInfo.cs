﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Volo.Abp.Auditing.Tests")]
