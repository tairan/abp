﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Button
{
    public enum AbpButtonSize
    {
        Default,
        Small,
        Large
    }
}