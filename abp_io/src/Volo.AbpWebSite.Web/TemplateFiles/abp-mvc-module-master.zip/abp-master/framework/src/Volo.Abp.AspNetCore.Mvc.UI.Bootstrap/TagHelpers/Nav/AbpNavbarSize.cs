﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Nav
{
    public enum AbpNavbarSize
    {
        Default,
        Sm,
        Md,
        Lg,
        Xl
    }
}