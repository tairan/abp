﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Border
{
    public enum AbpRoundedType
    {
        Default,
        _0,
        Top,
        Right,
        Left,
        Bottom
    }
}