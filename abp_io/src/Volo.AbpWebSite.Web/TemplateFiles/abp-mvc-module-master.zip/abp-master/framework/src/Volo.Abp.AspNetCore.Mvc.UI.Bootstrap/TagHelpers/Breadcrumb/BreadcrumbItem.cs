﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Breadcrumb
{
    public class BreadcrumbItem
    {
        public string Html { get; set; }

        public bool Active { get; set; }
    }
}
