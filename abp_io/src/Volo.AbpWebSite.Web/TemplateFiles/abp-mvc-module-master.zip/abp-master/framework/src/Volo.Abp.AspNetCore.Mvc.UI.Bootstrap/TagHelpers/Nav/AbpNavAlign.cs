﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Nav
{
    public enum AbpNavAlign
    {
        Default,
        Start,
        Center,
        End
    }
}