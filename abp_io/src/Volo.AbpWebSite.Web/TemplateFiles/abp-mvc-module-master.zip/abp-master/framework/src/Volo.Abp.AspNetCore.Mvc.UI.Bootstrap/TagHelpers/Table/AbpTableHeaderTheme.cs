﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Table
{
    public enum AbpTableHeaderTheme
    {
        Default,
        Light,
        Dark
    }
}