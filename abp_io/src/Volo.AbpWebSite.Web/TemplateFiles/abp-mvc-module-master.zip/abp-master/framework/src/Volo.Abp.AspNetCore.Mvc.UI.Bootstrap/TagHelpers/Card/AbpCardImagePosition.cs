﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Card
{
    public enum AbpCardImagePosition
    {
        None,
        Top,
        Bottom
    }
}