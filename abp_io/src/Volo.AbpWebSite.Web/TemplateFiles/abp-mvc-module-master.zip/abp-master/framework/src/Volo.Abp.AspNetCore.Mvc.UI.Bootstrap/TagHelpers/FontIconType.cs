﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers
{
    public enum FontIconType
    {
        FontAwesome,
        Other
    }
}