﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bundling.TagHelpers
{
    public static class AbpTagHelperConsts
    {
        public const string ContextBundleItemListKey = "AbpBundleFileTagHelperService.BundleFiles";
    }
}