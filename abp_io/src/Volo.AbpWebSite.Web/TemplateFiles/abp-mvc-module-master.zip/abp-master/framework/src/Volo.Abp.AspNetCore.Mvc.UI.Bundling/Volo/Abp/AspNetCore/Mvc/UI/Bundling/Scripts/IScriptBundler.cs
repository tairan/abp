namespace Volo.Abp.AspNetCore.Mvc.UI.Bundling.Scripts
{
    public interface IScriptBundler : IBundler
    {

    }
}