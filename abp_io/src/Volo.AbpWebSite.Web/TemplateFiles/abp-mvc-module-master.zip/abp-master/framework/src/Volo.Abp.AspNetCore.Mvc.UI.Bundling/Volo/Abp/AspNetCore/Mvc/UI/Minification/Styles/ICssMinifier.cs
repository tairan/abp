namespace Volo.Abp.AspNetCore.Mvc.UI.Minification.Styles
{
    public interface ICssMinifier : IMinifier
    {

    }
}