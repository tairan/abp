﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Theme.Shared.Toolbars
{
    public static class StandardToolbars
    {
        public const string Main = "Main";
    }
}