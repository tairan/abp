﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Nav
{
    public enum NavStyle
    {
        Default,
        Vertical,
        Pill,
        PillVertical
    }
}