﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Nav
{
    public class NavItem
    {
        public string Html { get; set; }

        public bool Active { get; set; }
    }
}