﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Theme.Basic.Themes.Basic.Components.Toolbar.LanguageSwitch
{
    public class LanguageInfo
    {
        public string Name { get; set; }

        public string DisplayName { get; set; }

        public string Icon { get; set; }
    }
}