﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers
{
    public enum HtmlHeadingType
    {
        H1,
        H2,
        H3,
        H4,
        H5,
        H6
    }
}