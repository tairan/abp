﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Popover
{
    public enum PopoverDirectory
    {
        Default,
        Right,
        Left,
        Bottom,
        Top
    }
}