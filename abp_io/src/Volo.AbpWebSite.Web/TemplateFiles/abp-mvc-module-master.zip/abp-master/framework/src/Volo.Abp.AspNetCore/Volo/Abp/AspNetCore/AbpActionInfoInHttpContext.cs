﻿namespace Volo.Abp.AspNetCore.Mvc
{
    public class AbpActionInfoInHttpContext //Rename?
    {
        public bool IsObjectResult { get; set; }
    }
}